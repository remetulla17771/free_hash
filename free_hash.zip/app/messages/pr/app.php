<?php

return [
    'hello' => 'Salem PR',
    'User not found' => 'Пользователь не найден',
];
