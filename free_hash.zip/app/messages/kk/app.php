<?php

return [
    'hello' => 'Salem',
    'User not found' => 'Пользователь не найден',
];
